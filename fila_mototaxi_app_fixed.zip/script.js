let lista = JSON.parse(localStorage.getItem('fila')||'[]');
render();

function add(){
  const nome=document.getElementById('nome').value.trim();
  if(!nome)return;
  lista.push({nome,corridas:0,hora:"--:--",rodando:false});
  save(); render();
}

function toggle(i){
  lista[i].rodando=!lista[i].rodando;
  save(); render();
}

function corrida(i){
  const d=new Date();
  lista[i].corridas++;
  lista[i].hora=d.toLocaleTimeString();
  save(); render();
}

function remover(i){
  lista.splice(i,1);
  save(); render();
}

function save(){
  localStorage.setItem('fila',JSON.stringify(lista));
}

function render(){
  const ul=document.getElementById('lista');
  ul.innerHTML='';
  lista.forEach((p,i)=>{
    const li=document.createElement('li');
    li.innerHTML = `<span class="${p.rodando?'verde':'vermelho'}">${p.nome}</span>
    | Corridas: ${p.corridas} | Hora: ${p.hora}
    <button onclick="corrida(${i})">+ corrida</button>
    <button onclick="toggle(${i})">Rodando/parou</button>
    <button onclick="remover(${i})">X</button>`;
    ul.appendChild(li);
  });
}
